/* jshint node:true */
/* jshint -W097 */
'use strict';

module.exports = require('./dist/api');
